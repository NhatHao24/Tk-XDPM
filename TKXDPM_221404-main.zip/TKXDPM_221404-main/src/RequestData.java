public class RequestData {
    String strNumber1;
    String strNumber2;

}
