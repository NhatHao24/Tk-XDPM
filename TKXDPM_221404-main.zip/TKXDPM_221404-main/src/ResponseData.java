public class ResponseData {
    String error, strNumber1, strNumber2;
    int result;

}
