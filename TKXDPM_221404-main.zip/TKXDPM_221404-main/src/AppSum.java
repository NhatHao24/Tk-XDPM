public class AppSum {
    public static void main(String[] args) throws Exception {
        System.out.println("Addition Application");
        AddUIConsoleInput addUIConsoleInput = new AddUIConsoleInput();
        addUIConsoleInput.input();
    }
}
